<?php
$servername = "localhost";      //variable
$username = "root";         //variable
$password = "";           //variable
$dbname = "smarthealth";   //variable
$conn = new mysqli($servername, $username, $password, $dbname); //connect with database
?>